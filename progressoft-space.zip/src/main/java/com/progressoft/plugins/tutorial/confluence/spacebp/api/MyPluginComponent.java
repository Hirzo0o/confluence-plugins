package com.progressoft.plugins.tutorial.confluence.spacebp.api;

public interface MyPluginComponent
{
    String getName();
}